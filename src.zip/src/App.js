import { Container } from "react-bootstrap";
import "./App.css";
import { MovieList } from "./components/MovieList";
import { SearchForm } from "./components/SearchForm";

import { Title } from "./components/Title";

function App() {
  return (
    <div className="wrapper ">
      <Container>
        <Title />
        {/* form */}
        <SearchForm />

        {/* movie List */}
        <MovieList />
      </Container>
    </div>
  );
}

export default App;
