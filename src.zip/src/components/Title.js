import React from "react";

export const Title = () => {
  return <h2 className="mt-5 text-center mb-2">My movie list</h2>;
};
